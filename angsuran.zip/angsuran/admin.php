<?php
error_reporting(0);
session_start();
include_once 'include/class.php';

$db = new Database();

// koneksi ke MySQL via method
$db->connectMySQL();

$user = new User();
$iduser = $_SESSION['id'];
if (!$user->get_sesi())
{
header("location:index.php");
}
if ($_GET['page'] == 'logout')
{
$user->user_logout();
header("location:index.php");
}
?>



<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<link rel="stylesheet" href="style.css" type="text/css"  />
<style>
  
  h1{
    background-color: #4169E1;
    padding: 1em;
    clear: left;
    text-align: center;
  }
  footer{
    background-color: #4169E1;
    padding: 1em;

  }
</style>
</head>

<body>

<form class="form1" name="form1" method="post" action="">
  <table width="946" height="auto" border="1" align="center">
    <tr>
      <td height="114" colspan="2" align="center"><strong><h1>APLIKASI PEMBAYARAN</h1></strong></td>
    </tr>
    <tr>
      <td width="189" height="221" align="left" valign="top"><table width="200" border="0" align="left" cellpadding="5">
        <tr>
          <td><a href="?page=home">Home</a></td>
        </tr>
        <tr>
          <td><a href="?page=nasabah_mgr">Nasabah</a></td>
        </tr>
        <tr>
          <td><a href="?page=pokok_mgr">Pokok Pinjaman</a></td>
        </tr>
        <tr>
          <td><a href="?page=lama_mgr">Lama Pinjaman</a></td>
        </tr>
        <tr>
          <td><a href="?page=pinjaman_mgr">Pinjaman</a></td>
        </tr>
        <tr>
          <td><a href="?page=logout">Keluar</a></td>
        </tr>
      </table></td>

      <td width="893" align="left" valign="top"><?php include "isi.php";?></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><strong><footer>CREATE BY KELOMPOK 9</footer></strong></td>
    </tr>
  </table>
</form>
</body>
</html>
